<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>FenetrePrincipale</name>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="14"/>
        <source>IDE Compact</source>
        <translation>IDE Compact</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="41"/>
        <source>Fichier</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="56"/>
        <source>Edition</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="63"/>
        <location filename="../src/fenetreprincipale.ui" line="234"/>
        <source>Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="71"/>
        <source>Émulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="81"/>
        <source>Débug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="89"/>
        <source>Affichage</source>
        <translation>View</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="117"/>
        <location filename="../src/fenetreprincipale.ui" line="358"/>
        <source>Fichiers dans le projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="151"/>
        <location filename="../src/fenetreprincipale.ui" line="380"/>
        <source>Résultats de compilation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="164"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="173"/>
        <location filename="../src/fenetreprincipale.ui" line="391"/>
        <source>Labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="188"/>
        <location filename="../src/fenetreprincipale.ui" line="369"/>
        <source>Fichiers ouverts</source>
        <translation>Open files</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="203"/>
        <source>Nouveau projet...</source>
        <translation>New project…</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="208"/>
        <source>Nouveau fichier...</source>
        <translation>New file…</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="213"/>
        <source>Ouvrir...</source>
        <translation>Open…</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="218"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="221"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="226"/>
        <source>Tout enregistrer</source>
        <translation>Save all</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="229"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="237"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="242"/>
        <location filename="../src/fenetreprincipale.ui" line="339"/>
        <source>Exécuter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="245"/>
        <location filename="../src/fenetreprincipale.ui" line="342"/>
        <source>F6</source>
        <translation>F6</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="250"/>
        <source>Quitter</source>
        <translation>Quit</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="261"/>
        <source>Mettre en mémoire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="269"/>
        <source>Mettre sur disquette</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="274"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="277"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="282"/>
        <source>Rétablir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="285"/>
        <source>Ctrl+Shift+Z</source>
        <translation>Ctrl+Shift+Z</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="290"/>
        <source>Afficher écran</source>
        <translation>Show screen</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="295"/>
        <source>Afficher RAM</source>
        <translation>Show RAM</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="300"/>
        <source>Afficher lecteur de disquettes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="305"/>
        <source>Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="308"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="313"/>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="318"/>
        <source>Arrêter</source>
        <translation>Stop</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="323"/>
        <source>Pas à pas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="326"/>
        <source>F10</source>
        <translation>F10</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="331"/>
        <source>Poser un point de contrôle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="334"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="347"/>
        <source>Stopper l&apos;émulation</source>
        <translation>Stop emulation</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="399"/>
        <source>Afficher sous forme d&apos;onglets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="404"/>
        <source>Afficher en cascade</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/fenetreprincipale.ui" line="409"/>
        <source>Afficher tout en même temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.ui" line="414"/>
        <location filename="../src/slots.cpp" line="208"/>
        <source>Fermer le projet</source>
        <translation>Close project</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.cpp" line="87"/>
        <source>Projet à ouvrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.cpp" line="87"/>
        <source>Projet (*.proj)</source>
        <translation>Project (*.proj)</translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.cpp" line="112"/>
        <location filename="../src/slots.cpp" line="129"/>
        <source>Fichier modifié</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/fenetreprincipale.cpp" line="112"/>
        <location filename="../src/slots.cpp" line="129"/>
        <source>Voulez vous sauvegarder &quot;%1&quot; ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/slots.cpp" line="189"/>
        <source>Ajouter fichier(s)</source>
        <translation>Add file(s)</translation>
    </message>
    <message>
        <location filename="../src/slots.cpp" line="190"/>
        <source>Fermer projet</source>
        <translation>Close project</translation>
    </message>
    <message>
        <location filename="../src/slots.cpp" line="208"/>
        <source>Projet en cours : %1
Projet sélectionné : %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NouveauFichier</name>
    <message>
        <location filename="../src/nouveaufichier.ui" line="14"/>
        <location filename="../src/nouveaufichier.ui" line="29"/>
        <source>Nouveau Fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveaufichier.ui" line="22"/>
        <source>Nom du fichier :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NouveauProjet</name>
    <message>
        <location filename="../src/nouveauprojet.ui" line="14"/>
        <location filename="../src/nouveauprojet.ui" line="48"/>
        <source>Nouveau projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="38"/>
        <source>Nom du projet :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="59"/>
        <source>Nom du fichier :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="72"/>
        <source>Nouveau fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="83"/>
        <source>Fin de fichier :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="91"/>
        <source>.dasm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="96"/>
        <source>.dcpu16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="121"/>
        <source>Chemin :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.ui" line="131"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/nouveauprojet.cpp" line="31"/>
        <source>Choisissez un dossier</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Sauver</name>
    <message utf8="true">
        <location filename="../src/sauver.ui" line="14"/>
        <source>Fichiers modifiés</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
